import React from 'react'
export default function Home(){
  return <div style={{padding:12}}><h2>Welcome</h2><p>This is a small demo combining TodoList + React Router.</p></div>
}

