import React from 'react'
export default function About(){
  return <div style={{padding:12}}><h2>About</h2><p>Demo app to show React Router features integrated with a TodoList.</p></div>
}

