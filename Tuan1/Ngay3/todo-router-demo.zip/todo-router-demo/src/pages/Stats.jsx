import React from 'react'
export default function Stats(){ return <div style={{padding:12}}>Stats page (protected)</div> }
