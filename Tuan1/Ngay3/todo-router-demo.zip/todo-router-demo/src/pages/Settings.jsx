import React from 'react'
export default function Settings(){ return <div style={{padding:12}}>Settings page (protected)</div> }
